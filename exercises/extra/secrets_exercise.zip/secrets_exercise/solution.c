#include "solution.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * TODO: implement encodec and encodec_list functions
 */


void encodec(char *msg, char *key, char *dst)
{
    // TODO
}

void encodec_list(Nodo *list, char *key)
{
    // TODO
}

int is_printable(char c)
{
    return c >= 32 && c <= 126;
}