#include "solution.h"
#include <stdio.h>

/**
 * 1. Implement the function `wc`, it should count the number of lines, words and characters in the given string and store the result in the `counter` struct.
 * 2. Implement the function `print_stats`, it should pretty print the number of lines, words and characters in the given `counter` struct.
*/

int is_empty(char c)
{
    return c == ' ' || c == '\n';
}

/**
 * TODO: implement this function
*/
void wc(const char *str, Stats *counter)
{

}

/**
 * TODO: implement this function
*/
void print_stats(Stats counter)
{

}
