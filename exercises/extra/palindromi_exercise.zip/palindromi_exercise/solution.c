#include "solution.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

void add(Nodo **lista, char c)
{
    // TODO
}

void copyReversed(Nodo *src, Nodo **copy)
{
    // TODO
}

int compareLists(Nodo *list_a, Nodo *list_b)
{
    // TODO
}

void print_list(Nodo *list)
{
    // TODO
}

int checkPalindrome(Nodo *lista)
{
    // TODO
}

void delete_list(Nodo *list)
{
    // TODO
}
